package com.example.goparty;

public class Party {
    private String party_name;

    public Party(String party_name) {
        this.party_name = party_name;
    }

    public String getParty_name() {
        return party_name;
    }

    public void setParty_name(String party_name) {
        this.party_name = party_name;
    }
}
